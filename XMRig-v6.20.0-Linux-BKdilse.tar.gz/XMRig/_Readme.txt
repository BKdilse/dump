Please find the latest info on our Wiki:

https://github.com/The-GNTL-Project/Documentation/wiki/XMRig
